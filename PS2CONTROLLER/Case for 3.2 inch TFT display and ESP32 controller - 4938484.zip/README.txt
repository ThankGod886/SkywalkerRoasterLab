Case for 3.2 inch TFT display and ESP32 controller by Druckelo on Thingiverse: https://www.thingiverse.com/thing:4938484
This case is from above; I modified it to install the entire package.

